function increment(element){
    element.innerText++
}